let ctx = canvas.getContext('2d')
const screenWidth = window.innerWidth
const screenHeight = window.innerHeight
let touchStartEvent = false


/**
 * 游戏主函数
 */
export default class Main {
  constructor() {
    // 维护当前requestAnimationFrame的id
    this.aniId = 0

    this.draw()
  }
  draw() {

    const bg = wx.createImage()
    bg.src = "./js/bg.png"
    bg.onload = function() {
      ctx.drawImage(
        bg,
        0,
        0,
        screenWidth,
        screenHeight
      )

      roundRect(ctx, screenWidth / 3, screenWidth / 3, screenWidth / 3, screenWidth / 3, 10, '#FFF386')
      roundRect(ctx, 0.3 * screenWidth, screenHeight / 1.7, screenWidth / 2.5, screenWidth / 8, 20, '#FFFFFF')
      ctx.fillStyle = "#ffffff"
      ctx.font = "70px Monaco"
      ctx.fillText(
        '24',
        screenWidth / 2 - 40,
        screenHeight / 3 - 10
      )
      ctx.fillStyle = "#000000"
      ctx.font = "20px Monaco"
      ctx.fillText(
        '开始游戏',
        screenWidth / 2 - 40,
        screenHeight / 1.7 + 30
      )
      ctx.font = "14px Monaco"
      ctx.fillText(
        '排行榜 >',
        screenWidth / 2 - 40,
        screenHeight / 1.7 + 80
      )
      ctx.fillText(
        '消息 >',
        screenWidth / 2 - 40,
        screenHeight / 1.7 + 110
      )
    }
    console.log('in draw')
    this.touchHandler = this.touchListenStart.bind(this)
    canvas.addEventListener('touchstart', this.touchHandler)
  }
  touchListenStart(e) {
    console.log(e.changedTouches);
    let x = e.changedTouches[0].clientX
    let y = e.changedTouches[0].clientY
    let startBtnArea = {
      startX: screenWidth / 2 - 70,
      startY: screenHeight / 1.7,
      endX: screenWidth / 2 + 70,
      endY: screenHeight / 1.7 + 50
    }

    if (x >= startBtnArea.startX &&
      x <= startBtnArea.endX &&
      y >= startBtnArea.startY &&
      y <= startBtnArea.endY) {
      this.game()
    }
  }
  game() {
    canvas.removeEventListener(
      'touchstart',
      this.touchHandler
    )
    console.log('touch it')
    ctx.clearRect(0, 0, screenWidth, screenHeight);
    const bg = wx.createImage()
    bg.src = "./js/bg.png"
    bg.onload = function() {
      ctx.drawImage(
        bg,
        0,
        0,
        screenWidth,
        screenHeight
      )
      roundRect(ctx, screenWidth / 10, screenWidth / 4, 0.8 * screenWidth, screenWidth / 4.8, 40, '#FFFfff')
      roundRect(ctx, screenWidth / 6, screenWidth / 1.95, 11 * screenWidth / 36, 7 * screenWidth / 24, 10, '#FFF386')
      roundRect(ctx, 19 * screenWidth / 36, screenWidth / 1.95, 11 * screenWidth / 36, 7 * screenWidth / 24, 10, '#FFF386')
      roundRect(ctx, screenWidth / 6, screenWidth / 1.17, 11 * screenWidth / 36, 7 * screenWidth / 24, 10, '#FFF386')
      roundRect(ctx, 19 * screenWidth / 36, screenWidth / 1.17, 11 * screenWidth / 36, 7 * screenWidth / 24, 10, '#FFF386')
      roundRect(ctx, screenWidth / 10, screenWidth / 0.83, 0.8 * screenWidth, screenWidth / 6.8, 30, '#FFFfff')
      roundRect(ctx, screenWidth / 10, screenWidth / 0.72, 0.2 * screenWidth, screenWidth / 6.8, 28, '#FFFfff')
      roundRect(ctx, 0.4 * screenWidth, screenWidth / 0.72, 0.2 * screenWidth, screenWidth / 6.8, 28, '#FFFfff')
      roundRect(ctx, 0.7 * screenWidth, screenWidth / 0.72, 0.2 * screenWidth, screenWidth / 6.8, 28, '#FFFfff')
      ctx.fillStyle = "#000000"
      ctx.font = "40px Monaco"
      ctx.fillText(
        '6+6+6+6=24', //just for demo
        screenWidth / 2 - 115,
        screenHeight / 4.5
      )
      ctx.fillStyle = "#ffffff"
      ctx.font = "70px Monaco"
      ctx.fillText(
        '6', //just for demo
        screenWidth / 2 - 90,
        screenHeight / 2.45
      )
      ctx.fillText(
        '6', //just for demo
        screenWidth / 2 + 45,
        screenHeight / 2.45
      )
      ctx.fillText(
        '6', //just for demo
        screenWidth / 2 - 90,
        screenHeight / 1.67
      )
      ctx.fillText(
        '6', //just for demo
        screenWidth / 2 + 45,
        screenHeight / 1.67
      )
      ctx.fillStyle = "#000000"
      ctx.font = "40px Monaco"
      ctx.fillText(
        '+', //just for demo
        screenWidth / 2 - 110,
        screenHeight / 1.35
      )
      ctx.fillText(
        '－', //just for demo
        screenWidth / 2 - 80,
        screenHeight / 1.35
      )
      ctx.fillText(
        '×', //just for demo
        screenWidth / 2 - 30,
        screenHeight / 1.35
      )
      ctx.fillText(
        '÷', //just for demo
        screenWidth / 2 + 15,
        screenHeight / 1.35
      )
      ctx.fillText(
        '(', //just for demo
        screenWidth / 2 + 50,
        screenHeight / 1.35
      )
      ctx.fillText(
        ')', //just for demo
        screenWidth / 2 + 90,
        screenHeight / 1.35
      )
      ctx.font = "18px Monaco"
      ctx.fillText(
        'Home', //just for demo
        screenWidth / 2 - 20,
        screenHeight / 1.2
      )







    }
    this.touchHandler = this.touchListenRestart.bind(this)
    canvas.addEventListener('touchrestart', this.touchHandler)
    console.log("b")

  }
  touchListenRestart(f) {
    console.log("a")
    let x = f.changedTouches[0].clientX
    let y = f.changedTouches[0].clientY
    let startBtnArea = {
      startX: screenWidth / 2 - 70,
      startY: screenHeight / 1.7,
      endX: screenWidth / 2 + 70,
      endY: screenHeight / 1.7 + 50
    }

    if (x >= startBtnArea.startX &&
      x <= startBtnArea.endX &&
      y >= startBtnArea.startY &&
      y <= startBtnArea.endY) {
      this.draw()
    }

  }
}

function roundRect(ctx, x, y, w, h, r, color) {
  // 开始绘制
  ctx.beginPath()
  // 因为边缘描边存在锯齿，最好指定使用 transparent 填充
  // 这里是使用 fill 还是 stroke都可以，二选一即可
  ctx.fillStyle = color
  // ctx.setStrokeStyle('transparent')
  // 左上角
  ctx.arc(x + r, y + r, r, Math.PI, Math.PI * 1.5)

  // border-top
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.lineTo(x + w, y + r)
  // 右上角
  ctx.arc(x + w - r, y + r, r, Math.PI * 1.5, Math.PI * 2)

  // border-right
  ctx.lineTo(x + w, y + h - r)
  ctx.lineTo(x + w - r, y + h)
  // 右下角
  ctx.arc(x + w - r, y + h - r, r, 0, Math.PI * 0.5)

  // border-bottom
  ctx.lineTo(x + r, y + h)
  ctx.lineTo(x, y + h - r)
  // 左下角
  ctx.arc(x + r, y + h - r, r, Math.PI * 0.5, Math.PI)

  // border-left
  ctx.lineTo(x, y + r)
  ctx.lineTo(x + r, y)

  // 这里是使用 fill 还是 stroke都可以，二选一即可，但是需要与上面对应
  ctx.fill()
  // ctx.stroke()
  ctx.closePath()
  // 剪切

}